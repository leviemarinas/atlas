# Installing

Unzip `live-prototype-deck/` into one of:

| Location | Scope |
|---|---|
| `~/.claude/skills/live-prototype-deck/` | every project on this machine |
| `<project>/.claude/skills/live-prototype-deck/` | one project, shareable via git |

`SKILL.md` must sit at the top of that folder:

```
.claude/skills/live-prototype-deck/
  SKILL.md
  INSTALL.md
  brand.json.example
  scripts/      engine — copy into each project's build/ folder
  templates/    starting points — copy and fill in
  references/   house style, capture recipes, troubleshooting
  examples/     a real 49-slide build, for reference
```

Restart Claude Code, or start a new session, and it will pick the skill up.

## Requirements

```bash
pip install -r scripts/requirements.txt
```

Pillow, requests, websockets, python-pptx — plus a Chrome or Edge install. Set
`CHROME` if the binary is somewhere unusual; `cdp.py` checks the common paths.

PowerPoint is *not* required. `render_preview.py` draws the finished deck back
to PNGs so layout can be checked without it.

## Starting a project

```bash
mkdir -p mydeck/{build,outputs,evidence}
cp .claude/skills/live-prototype-deck/scripts/*.py     mydeck/build/
cp .claude/skills/live-prototype-deck/templates/*.py   mydeck/build/
cp .claude/skills/live-prototype-deck/brand.json.example mydeck/build/brand.json
cd mydeck/build
```

Then fill in `nav.py` first — nothing else works until the app opens reliably —
followed by the capture scripts, `content.py` and `build_deck.py`.

```bash
python run_all.py
```

Ends with contact sheets in `build/preview/` and a house-rules check. Look at
the contact sheets before calling the deck finished.

## Using it by name

Ask for a walkthrough deck and the skill triggers on its description. To force
it: *"use the live-prototype-deck skill to rebuild the X deck."*
