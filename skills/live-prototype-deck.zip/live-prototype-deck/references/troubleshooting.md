# Troubleshooting

## Capture

**`Chrome did not expose a page target`** — the binary was not found or failed to
start. Set `CHROME` to the executable path. On a locked-down machine, try Edge:
`msedge.exe` speaks the same protocol.

**Images come out 4x the expected size** — a clip was passed with `scale: 2` on
top of `deviceScaleFactor: 2`. Clip scale must be `1`; `cdp.shot()` already does
this.

**`click_text` finds nothing** — the label is inside a child element, so the
tag filter excluded the parent. Drop `tag=`, or click via `js()`.

**A `<select>` change does not stick** — you assigned `.value` directly. Use
`set_input`, which calls the native setter and fires `input`/`change`.

**An anchor is missing** (`! anchor missing: name/key`) — the element was not on
screen when `capture()` ran. Usually the panel had not opened yet; add
`wait_rect` or increase `settle`.

**Seeded data has vanished** — headless Chrome did not flush localStorage.
Seed and capture in one session. Never run two Chrome instances against the same
`--user-data-dir`.

**Leftover headless Chrome processes** — filter strictly on `--headless=new`
*and* your profile path before killing anything, or you will close the user's
real browser.

## Layout

**Text overflows a card** — `render_preview.py` reports it with a pixel amount.
`fit_size` already shrinks to a floor; past that, shorten the copy. A note
needing more than about 30 words is usually two notes.

**A screenshot is unreadably small** — the layout traded image size for note
space. Reduce the number of markers (seven is the practical ceiling), or split
the slide into two field-guide pages.

**A slide has a large empty band** — a wide, short image centred in a tall box.
`guide()` and `screen()` centre the image-plus-notes block together to avoid
this; if you wrote a custom layout, do the same.

**Markers collide with numbers already on screen** — set `"annotate": False`
and use the app's own numbers as the note labels.

**A badge covers the field label** — set `"side": "right"` on that field guide.
Form fields put their label at the left edge, so a top-left badge lands on the
first word.

## Build

**`PermissionError` saving the .pptx** — it is open in PowerPoint. The build
stages to a `-NEW` file; close the deck and run `promote.py`.

**Fonts look wrong in the render but fine in PowerPoint** — expected. The
preview renderer measures with whatever TTFs exist locally; PowerPoint uses the
family names. Trust the preview for geometry, not for typography.

**GIF does not animate in PowerPoint** — check the media part is really a `.gif`
(`zipfile.ZipFile(deck).namelist()`). Animated GIFs play in Slide Show, not in
editing view.

**Deck is over ~8 MB** — usually the GIFs. Lower `width` in `make_gifs.build`,
or capture a tighter window. 400–500 KB per GIF is a good target.

## Content

**`check_deck.py` reports `counts`** — a catalogue total from the prototype.
Replace with a description of the kind of thing. If it is a genuine
demonstration figure inside a worked example, rephrase the sentence so the
number is not adjacent to a catalogue noun, and label the column
"In this demonstration".

**`check_deck.py` reports `negative`** — see the rewrite table in
`house-style.md`. If the phrase is genuinely fine ("rather than", "instead of"),
add it to `ALLOWED` in the linter rather than weakening the pattern.

**`check_deck.py` reports `path`** — a screenshot page with no navigation chip.
Pass `path=` to the layout, or add `"path"` to that entry in `content.py`.
