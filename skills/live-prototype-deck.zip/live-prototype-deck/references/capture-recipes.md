# Capture recipes

Patterns for driving a React/SPA prototype over CDP. All of these come from real
captures; each solves a problem you will otherwise hit.

---

## Getting a browser

```python
from cdp import Chrome
c = Chrome(width=1600, height=1000, scale=2)      # 16:10 fits a 16:9 slide well
```

`scale=2` renders at 2x. A clip passed to `shot()` uses `scale: 1` on top of
that, because the device scale factor already applies — set both and you get 4x
images and a confusing debugging session.

Always `c.close()`. It sends `Browser.close`, then falls back to killing the
process tree; Chrome children otherwise keep a profile directory locked.

## Navigating an app with no deep links

Most prototypes hold navigation in React state, so there is no URL to jump to.
Click through, and put it in one reusable function:

```python
def open_module(c):
    c.goto(BASE, settle=3.0)
    select_company(c)
    c.click_text("Company Configuration")
    c.click_text("Services Information", settle=1.2)
    c.click_text("Payroll", tag="button", settle=1.2)
    c.click_text("Computational Basis", settle=1.8)
    c.wait_text("governed computations")     # prove you arrived
```

End every navigation helper with `wait_text` on something only that screen says.

`click_text` skips an element whose child also matches, so it clicks the leaf.
When a button wraps its label in a `<span>`, `tag="button"` finds nothing —
either drop the tag filter or click directly:

```python
c.js("[...document.querySelectorAll('button')].find(e=>e.textContent.trim()==='Scenarios').click()")
```

## Setting React-controlled inputs

Assigning `.value` does not update React state. `cdp.set_input` calls the native
setter and dispatches `input` + `change`, which does:

```python
c.set_input("section.modal input[placeholder^='e.g.']", "CUS-900")
c.set_input(".modal select", "Earnings", nth=0)
```

For a `<select>` whose option text you know but whose value you do not:

```python
opt = c.js("(()=>{const s=[...document.querySelectorAll('.modal select')][2];"
           "const o=[...s.options].find(o=>o.text.includes('CUS-900'));return o?o.value:''})()")
c.set_input(".modal select", opt, nth=2)
```

## Waiting for drawers and modals

Different overlays use different classes — `section.modal`, `aside.record-drawer`,
`[role=dialog]`. Find the real one once, then wait for it:

```python
r = c.wait_rect(".record-drawer", timeout=8)
```

To discover it, walk up from a known label:

```python
c.js("""(() => {
  const h=[...document.querySelectorAll('*')].find(e=>e.textContent.trim()==='Create computation');
  let n=h, out=[];
  while(n && n!==document.body){ out.push(n.tagName+'.'+n.className); n=n.parentElement; }
  return out.join(' <<< ');
})()""")
```

## Framing a capture

Compute the clip from the elements that belong in shot:

```python
toolbar = _rect_of(c, selector="input[placeholder^='Search']")
last_row = c.js("(()=>{const t=[...document.querySelectorAll('table tbody tr')][9];"
                "if(!t)return null;const r=t.getBoundingClientRect();"
                "return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
capture(c, "register", clip_rect=span(toolbar, last_row, pad=22), anchors={...})
```

Anchor a container by its *parent* when a text match lands inside a card:
matching "governed computations" hits the label, and clipping to that gives you
one card instead of the row. `e.parentElement.getBoundingClientRect()` fixes it.

Content below the fold captures fine — `shot()` sets `captureBeyondViewport`
whenever a clip is given, so a 4000px-tall trail can be sliced without scrolling.

## Frames for a GIF

```python
GIF_CLIP = (330, 88, 1270, 912)      # one window for every frame

def frame(c, hold=1):
    for _ in range(hold):
        seq[0] += 1
        c.shot(f"gif-create/f{seq[0]:03d}.png", clip=GIF_CLIP)
```

Call `frame(c, 6)` on the states worth pausing on. Identical consecutive frames
collapse into one frame with a longer duration when the GIF is built, so a hold
costs nothing in file size.

Keep the page visible behind the modal. A tight crop of just the dialog loses
the sense that this is the real application.

## Seeding data

Some captures need state that does not exist yet — a posted transaction, an
approved request. If the app ships a demo or scenario runner, drive it:

```python
c.js("[...document.querySelectorAll('button')].find(e=>e.textContent.trim()==='Scenarios').click()")
...
for _ in range(90):
    time.sleep(4)
    if "7 of 7" in c.js("(()=>{const el=document.querySelector('.progress');return el?el.innerText:''})()"):
        break
```

**Seed and capture in the same browser session.** Headless Chrome does not
reliably flush localStorage to disk between runs, so data written by one script
may be gone when the next starts. Two Chrome instances sharing a `--user-data-dir`
will also lose writes.

Seeding may leave the app in a different role or tenant. Reset both afterwards:

```python
select_role(c, "Client Admin")
select_company(c, "Acme Corp")
```

## Making a run repeatable

Have the first capture script clear the module's stores so it always starts from
the seed state:

```python
for key in ("app-library-v3", "app-assignments-v3", "app-history-v3"):
    c.js("localStorage.removeItem(%r)" % key)
c.goto(BASE, settle=3.0)
```

Later scripts must *not* reset, or they will wipe the record an earlier script
created. Capture a register both before and after a demo record is added if you
need both states — do not reuse one image for both.
