# House style

Rules a client has already pushed back on. `scripts/check_deck.py` enforces the
first three mechanically.

---

## 1. Never quote catalogue counts from a prototype

A prototype's records are test data. Writing "219 governed computations" or
"30 reference sources" tells the client they have 219 of something, which is
not true and is embarrassing to walk back in the meeting.

> **No** — "The formula library: 219 governed computations, of which 209 are active."
> **Yes** — "The formula library. This is where a calculation is written, tested,
> dated and published as a version."

Describe the *kinds* of thing present instead of counting them. A slide that
wanted to say "the library is big, most of what you need already exists" works
better as six cards naming the families of formula than as a row of numbers.

**Demonstration figures inside a worked example are different** and should be
kept — a calculation with no numbers teaches nothing. Label them:

- put "In this demonstration" in the column header, not "In this run";
- add a sample-data line to the footnote and the speaker notes;
- say it once on the "how to read this deck" page.

## 2. Frame everything as capability, not deficiency

The deck is a walkthrough, not a defect report. Anything the product does not
yet do is either irrelevant to the client or a decision to make together.

| Instead of | Write |
|---|---|
| "What X does — and does not — do" | "What the X record captures" |
| "…and it did not run" | "What makes it produce an amount" |
| "the part they do not tell you" | "…lists every dependency" |
| "decisions the screen cannot make for you" | "decisions to agree before go-live" |
| "Where the prototype stands today" | "What this walkthrough covered" |
| "Works today / You must decide" | "Walkthrough / For the meeting" |

Where something genuinely is not built, do not catalogue the absence. State the
question it raises, put it on the decisions page, and mark the page **for the
meeting**. The client should see an agenda, not a scorecard.

The `LIVE`/`DECIDE` colour pair exists for exactly this: teal for what is shown
on a live screen, amber for what the meeting will agree. Never a red for "broken".

Being positive is not the same as being vague. If you corrected a factual claim
from an earlier version, say so plainly in the hand-off note to the user — just
not on a client slide.

## 3. Every screenshot page carries its navigation path

A client cannot act on a screen they cannot find. Put the path in a chip under
the heading, in the app's own breadcrumb wording:

```
Core › Company Configuration › Services Information › Payroll › Computational Basis › Computations
```

Go all the way down to the tab or dialog the slide actually shows
(`… › Create computation › Test calculation`). Where a slide compares two
places, give both paths as a row in the table.

`layouts.page(..., path=...)` renders it and moves the subhead down. `body_top()`
tells each layout where content starts.

## 4. One tenant, one journey, one pass

Every screenshot comes from the same company/tenant and the same rebuild.
Mixing captures from before and after a demo record was created produces a
slide claiming six of something beside a screenshot showing seven — which
readers notice and trust less for.

The first capture script resets the app's stores. Re-run the whole pipeline
rather than patching one image.

## 5. Notes carry the caveats

Every slide gets speaker notes. The standard block names the evidence and
repeats the demonstration-data caveat, so a presenter who opens on any slide has
the context.

## 6. Voice

- Second person, present tense: "Search the code when you know it."
- Say what a field is *for*, not what it is named. The screenshot already shows
  the name.
- One idea per note. If a note needs a semicolon and an "and also", split it.
- Prefer the concrete: "Choose the smallest group that genuinely shares the
  rule" over "Consider scope carefully."
- No exclamation marks, no "simply", no "just".
- Titles are sentences with a point of view — "Finding the right formula before
  you touch anything" — not labels like "Computation register".
