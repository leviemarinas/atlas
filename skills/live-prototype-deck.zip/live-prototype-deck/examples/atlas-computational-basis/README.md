# Worked example — ATLAS Computational Basis

The real capture scripts behind a 49-slide client walkthrough, kept as reference.
They will not run outside that project; read them for the patterns, then adapt
`templates/` to your own app.

| File | Worth reading for |
|---|---|
| `atlas_nav.py` | Navigating a state-driven SPA with no deep links; switching tenant and role; seeding a posted transaction by driving the app's own scenario runner in the same session |
| `capture_basis.py` | Framing a region from element rects; capturing table column headers as anchors; resetting stores so the run is repeatable |
| `capture_create.py` | Driving a multi-tab form end to end; setting React-controlled inputs; a fixed GIF window with `hold` beats |
| `capture_rest.py` | Waiting for a drawer whose class differs from the modal; capturing a register both before and after a record is added |
| `capture_trail.py` | Slicing a 4,000px-tall page into readable sections with `captureBeyondViewport`; expanding a row to capture its detail |
| `content.py` | A full copy spec: paths, marker notes, `side` and `annotate: False` in real use |
| `build_deck.py` | Every layout in anger, and the lock-safe save |
| `prepare_images.py` | The annotate-then-frame pass |
| `update_registers.py` | Project-specific: refreshing a cycle's `cycle.json`, `source-register.csv` and `deck-traceability.csv` after a rebuild. Adapt or drop |

## What the deck looked like

49 slides, 4.1 MB, two embedded GIFs at 427 KB and 141 KB. Structure:

1. Orientation — the model, where it lives, what the library holds, vocabulary
2. Create a computation — the register, then a five-panel field guide
3. Assign it — the register, the form, the scope rules to agree
4. Reference sources — two registers compared, source anatomy, change history
5. Proof — a posted payroll, the source trail, the calculation ledger
6. Connecting it up — the input contract and two worked examples
7. Decisions — five to agree, a summary, an evidence appendix, four takeaways

## Two decisions from that project worth carrying forward

**Capture everything in one tenant.** The payroll evidence only existed in one
sandbox company, so the entire deck was captured there rather than mixing
tenants across slides.

**Reset first, then build up.** `capture_basis.py` clears the module's stores;
`capture_create.py` creates the demonstration record; `capture_rest.py` assigns
it. Running them in that order means a register screenshot taken before the
record was added, and one taken after, both exist and are used where each
belongs — instead of one image doing both jobs badly.
