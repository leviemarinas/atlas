---
name: live-prototype-deck
description: Build a client walkthrough deck from a running web prototype by driving the app yourself — capturing every screen over the Chrome DevTools Protocol, placing numbered callouts from live DOM rectangles, recording animated GIFs of real workflows, and assembling a PowerPoint with python-pptx. Use when asked to produce, redo or improve a demo, pre-meeting, walkthrough or field-guide deck for an app or prototype; when existing deck screenshots are mis-cropped or callouts point at the wrong thing; or when a deck must show where each screen lives and how a feature is reached.
---

# Live prototype walkthrough decks

Build the deck from the running app, not from screenshots somebody handed you.
Every screen is captured over the DevTools protocol, and the numbered markers are
drawn from the field rectangles recorded at capture time — so a marker cannot point
at the wrong control, which is the failure this whole approach exists to prevent.

## When to use this

Producing or reworking a deck that walks a client through a product: demo decks,
pre-meeting walkthroughs, field guides, training material, UAT briefings.

Do not use it for decks with no product screens in them.

## Before you start

Confirm these four things, asking only if you cannot determine them yourself:

1. **The app URL and how to run it.** Check for `.claude/launch.json`, a `dev`
   script in `package.json`, or a server already listening.
2. **The module or journey** the deck covers, and its navigation path from the
   app's home screen.
3. **Which company / tenant / account** to capture in. Use one for the whole
   deck — mixed tenants across slides look like a mistake.
4. **Whether the data is real or demonstration data.** Almost always the latter.
   It changes the copy rules; see below.

Then read `references/house-style.md`. It is short, and it encodes decisions a
client has already pushed back on — skipping it means rediscovering them.

## The pipeline

Work in a `build/` folder beside the deck's `outputs/` and `evidence/` folders.
Copy `scripts/*` into it, then write the four project-specific files from
`templates/`.

| Step | File | What it does |
|---|---|---|
| 1 | `nav.py` | Navigating your app: open the module, switch tenant/role, seed data |
| 2 | `capture_*.py` | Drive each screen, capture it, record field anchors |
| 3 | `make_gifs.py` | Assemble frame folders into walkthrough GIFs |
| 4 | `content.py` | All deck copy, including per-marker notes |
| 5 | `prepare_images.py` | Draw markers from anchors, round and shadow every screen |
| 6 | `build_deck.py` | Assemble the PPTX from `layouts.py` |
| 7 | `render_preview.py` | Render the finished file back to PNGs, report overflow |
| 8 | `check_deck.py` | Lint against the house rules |

`run_all.py` runs them in order. **Order matters**: the first capture script
resets the app's stores so counts, screenshots and copy always agree. Never
hand-edit a capture — re-run the pipeline.

## Capturing

`cdp.py` launches headless Chrome and speaks CDP. `shotkit.capture()` writes a
PNG *and* the pixel rectangle of every anchor you name:

```python
capture(c, "cb-register",
        clip_rect=span(toolbar, table, pad=22),
        anchors={"search": toolbar, "create": _rect_of(c, text="Create", tag="button")})
```

Rules that matter:

- **Frame on purpose.** Compute the clip from the elements you want in shot
  (`span()` gives their bounding box). Never capture the full page and crop later.
- **Capture at `scale=2`.** Slides are printed and projected.
- **One anchor per note.** `content.py` pairs them positionally, so they cannot
  drift apart.
- **Never annotate over the app's own numbering.** If a screen already shows
  step numbers, set `"annotate": False` and reuse those numbers as the note
  labels. Two competing numbering systems on one image is unreadable.
- **GIF frames use a fixed clip.** A clip that tracks a modal makes the
  animation jump. Pick one window that contains every state, and use `hold` to
  pause on the beats that matter.

See `references/capture-recipes.md` for the CDP patterns — clicking by text,
setting React-controlled inputs, waiting for drawers, seeding state.

## Layouts

`layouts.py` provides `cover`, `section`, `guide`, `screen`, `cards`, `matrix`,
`split`, `stats`, `gif_slide`, `closing`. They share one page frame — eyebrow,
heading, path chip, subhead, body, footnote — so the deck reads as one document.

`guide()` picks its own arrangement: wide screenshots run across the top with
notes beneath, everything else puts the screen left and notes right, splitting
into two note columns when there are five or more. Text auto-fits: a long
sentence shrinks rather than spilling. You do not need to tune this by hand.

## Verifying

There is usually no PowerPoint on the machine. `render_preview.py` reads the
generated file back and draws every shape with PIL — font metrics differ
slightly, but it reliably catches overlapping boxes, text overrunning its frame,
and images placed outside their intended area. Then `contact_sheet.py` tiles the
slides 15 at a time so you can see the deck's rhythm.

**Look at the contact sheets before saying you are done.** Overflow reports do
not catch a screenshot that is unreadably small, a slide with a large empty band,
or three text-heavy pages in a row.

Finish with `check_deck.py`. A clean run means: no catalogue counts, no
deficiency framing, every screenshot page carries a path, every slide has notes.

## If the deck is open in PowerPoint

`build_deck.py` stages to a `-NEW` file when the target is locked and says so.
Close the deck and run `promote.py` to move it into place.

## Reporting back

Say what you captured, what you changed and why. Where you corrected a claim in
a previous version, name the file or screen you checked it against. Flag
anything you assumed — the tenant you captured in, whether demonstration
figures were kept — so the user can redirect you cheaply.
