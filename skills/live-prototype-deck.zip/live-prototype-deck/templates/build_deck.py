# -*- coding: utf-8 -*-
"""Assemble the deck.

Every layout takes the same shape — eyebrow, heading, path, subhead, body,
footnote — so the deck reads as one document. See layouts.py for the full set:
cover, section, guide, screen, cards, matrix, split, stats, gif_slide, closing.
"""
import os

from pptx import Presentation
from pptx.util import Inches

import content as C
from layouts import (cards, closing, cover, gif_slide, guide, matrix, screen,
                     section, split, stats)
from theme import DECIDE, DECIDE_WASH, LIVE, LIVE_WASH, VIOLET, VIOLET_2, WASH, notes

DECK = "MyProduct_Walkthrough_v01"
OUT = os.path.join("..", "outputs", DECK + ".pptx")
EVIDENCE = os.path.join("..", "evidence")

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)

# Repeated on every slide so a presenter opening at any page has the context.
NOTE = ("Presenter note: use the language the audience uses. For every screen, say what "
        "the user enters, where the value comes from, and what happens next. The records "
        "and amounts on screen are demonstration data.\n\n"
        "Evidence: live prototype captured <DATE>; <source files>.")


def n(slide, text=""):
    notes(slide, (text + "\n\n" if text else "") + NOTE)


# ─────────────────────────────────────────────────────────────── orientation
n(cover(prs, "Product · Module",
        "The Module Name",
        "One sentence saying what the audience will be able to do afterwards.",
        ["Create", "Test", "Assign", "Prove"],
        "Walkthrough · every field explained · every screen captured live on <DATE>"),
  "Open by saying what the session is for.")

n(cards(prs, "Why we are here", "What you will be able to do after this session",
        "Five outcomes. The rest of the deck exists to deliver them.",
        [("Outcome one", "What they will be able to do, concretely."),
         ("Outcome two", "…"),
         ("Outcome three", "…"),
         ("Outcome four", "…"),
         ("Outcome five", "…")],
        cols=5, body_size=10.2,
        note="Every claim in this deck is a live screen capture or a named source file."))

# Walkthrough pages vs pages that set up a decision. Never "works / broken".
n(split(prs, "How to read this deck", "Two kinds of page, marked differently",
        "Most pages walk through a screen. A few set up a decision for the meeting.",
        ("WALKTHROUGH", VIOLET, WASH,
         [("A screen and its fields", "Captured live, with notes placed on the control each describes."),
          ("A navigation path", "Every screen page carries the path to reach it."),
          ("Demonstration data", "Records and amounts on screen are sample data.")]),
        ("FOR THE MEETING", DECIDE, DECIDE_WASH,
         [("A decision to agree", "Where the business rule is a choice, not a setting."),
          ("Gathered at the end", "Repeated on the decisions page, so nothing is hunted for."),
          ("Owned by both sides", "Choices for the business and the implementer together.")]),
        note=C.SAMPLE))

n(screen(prs, "overview", C.SCREENS["overview"],
         [("Follow the path", "…"), ("Second point", "…"), ("Third point", "…")]))

# ─────────────────────────────────────────────────────────────── the walkthrough
n(section(prs, 1, "Section title",
          "One sentence on what this section delivers.",
          ["First beat", "Second beat", "Third beat"]))

for key in ["fg-register"]:
    n(guide(prs, dict(C.FIELD_GUIDES[key], _key=key)))

n(gif_slide(prs, "Demonstration", "The workflow, start to finish",
            "Watch it once here; the next pages take it apart field by field.",
            os.path.join(EVIDENCE, "workflow-walkthrough.gif"),
            [("Step one", "What happens and why."),
             ("Step two", "…"),
             ("Step three", "…"),
             ("Step four", "…")],
            path=C.MODULE + " › Records › Create",
            note="Captured live; the animation is the real prototype."))

n(matrix(prs, "An important distinction", "Heading with a point of view",
         "One sentence on why the distinction matters to the audience.",
         ["Kind", "What it means", "Where you change it", "What it looks like"],
         [["First", "…", "…", "…"],
          ["Second", "…", "…", "…"]],
         widths=[0.20, 0.25, 0.26, 0.29],
         path=C.MODULE,
         note="Read from a live screen."))

# ─────────────────────────────────────────────────────────────────── close
n(cards(prs, "For the meeting", "Decisions to agree before go-live",
        "Each has come up in this walkthrough. They are business choices to make together.",
        [("First decision", "What has to be agreed, and by whom."),
         ("Second decision", "…"),
         ("Third decision", "…")],
        cols=3, accent=DECIDE, wash=DECIDE_WASH, body_size=10.2,
        note="Every item traces back to a page earlier in this deck."))

n(closing(prs, "Four things to take away",
          [("First", "…"), ("Second", "…"), ("Third", "…"), ("Fourth", "…")],
          "Product · Module · walkthrough · <DATE>"))

# ── save, staging beside the target if it is open in PowerPoint ────────────
os.makedirs(os.path.dirname(OUT), exist_ok=True)
count = len(prs.slides.__iter__.__self__._sldIdLst)
staged = OUT + ".staged"
prs.save(staged)
try:
    os.replace(staged, OUT)
    print(f"saved {OUT}  ({count} slides)")
except PermissionError:
    fallback = OUT.replace(".pptx", "-NEW.pptx")
    try:
        os.replace(staged, fallback)
    except PermissionError:
        fallback = staged
    print(f"saved {fallback}  ({count} slides)")
    print(f"NOTE: {os.path.basename(OUT)} is open in another program. "
          f"Close it and run promote.py.")
