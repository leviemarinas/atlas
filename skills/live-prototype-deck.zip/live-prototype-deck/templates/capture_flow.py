# -*- coding: utf-8 -*-
"""Walk a workflow: field-guide stills plus GIF frames.

Runs AFTER capture_main.py and does not reset, so it can build on the state
that script left behind.
"""
import os
import shutil

from nav import open_module
import shotkit as sk
from shotkit import capture, span, bbox, _rect_of

GIF = "gif-flow"
shutil.rmtree(GIF, ignore_errors=True)
os.makedirs(GIF, exist_ok=True)
seq = [0]

# One fixed window for every frame. A clip that tracked the dialog would make
# the animation jump each time the dialog resized.
GIF_CLIP = (330, 88, 1270, 912)


def frame(c, hold=1):
    """`hold` repeats a frame; identical frames collapse into a longer pause."""
    for _ in range(hold):
        seq[0] += 1
        c.shot(os.path.join(GIF, f"f{seq[0]:03d}.png"), clip=GIF_CLIP)


def label_rect(c, text, nth=0, scope="section.modal"):
    """The whole label block — caption plus its control — for a form field."""
    return c.js("""
    (() => {
      const l = [...document.querySelectorAll(%r + ' label')]
        .filter(e => (e.innerText||'').trim().split('\n')[0] === %r)[%d];
      if (!l) return null;
      const r = l.getBoundingClientRect();
      return {x:r.x, y:r.y, width:r.width, height:r.height};
    })()""" % (scope, text, nth))


c = open_module()
c.click_text("Create", tag="button", settle=1.6)
c.wait_rect("section.modal")
frame(c, 6)

c.set_input("section.modal input", "DEMO-001")
frame(c, 2)
c.set_input("section.modal select", "Earnings", nth=0)
frame(c, 3)

capture(c, "form",
        clip_rect=span(_rect_of(c, selector="section.modal"), pad=16),
        anchors={
            "code": label_rect(c, "Code"),
            "category": label_rect(c, "Category"),
        })

c.click_text("Save", tag="button", settle=2.0)
frame(c, 10)

sk.save("shots/anchors-flow.json")
c.close()
print("flow captures done; frames:", seq[0])
