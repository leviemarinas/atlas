# -*- coding: utf-8 -*-
"""Navigating THIS app. The only file that knows your product's screens.

Fill in the four helpers below, then every capture script imports from here.
End each navigation helper with wait_text on something only that screen says,
so a capture never runs against a half-loaded page.
"""
import time

from cdp import Chrome

BASE = "http://localhost:5173/"
TENANT = "Acme Corporation"        # capture the whole deck in one tenant
ROLE = "Administrator"             # and one role

# Stores cleared by the FIRST capture script so a run always starts from seed
# state. Later scripts must not reset, or they wipe what an earlier one created.
RESET_KEYS = [
    # "app-library-v1",
]


def browser(width=1600, height=1000, scale=2, port=9333):
    """16:10 at 2x — fits a 16:9 slide with room for a caption, prints cleanly."""
    return Chrome(width=width, height=height, scale=scale, port=port)


def select_tenant(c, name=TENANT):
    current = c.js("(()=>{const b=document.querySelector('.tenant-switch');"
                   "return b?b.innerText:''})()")
    if name in (current or ""):
        return
    c.click_text(name, settle=1.8)


def select_role(c, role=ROLE):
    """Seeding flows often leave the app in another role; put it back."""
    c.js("(()=>{const b=[...document.querySelectorAll('button')]"
         ".find(e=>e.innerText.trim()===%r);if(b)b.click();})()" % role)
    time.sleep(1.5)


def open_module(c=None, reset=False, **kw):
    """Navigate to the module this deck covers."""
    if c is None:
        c = browser(**kw)
    c.goto(BASE, settle=1.2)
    if reset:
        for key in RESET_KEYS:
            c.js("localStorage.removeItem(%r)" % key)
    c.goto(BASE, settle=3.0)
    select_tenant(c)

    # --- replace with your app's click path -------------------------------
    # c.click_text("Settings")
    # c.click_text("Billing", tag="button", settle=1.2)
    # ---------------------------------------------------------------------

    c.wait_text("SOMETHING ONLY THIS SCREEN SAYS")
    return c


def dump(c, needle=None, n=4000):
    """Print the page text — the fastest way to learn a screen's structure."""
    text = c.js("document.body.innerText")
    if needle:
        i = text.find(needle)
        text = text[i:] if i >= 0 else text
    return text[:n]
