# -*- coding: utf-8 -*-
"""All deck copy.

FIELD_GUIDES entries pair each screenshot anchor with the note that describes
it. prepare_images.py and build_deck.py both read this list, so the marker on
an image and the note beside it cannot drift apart.

Two rules, enforced by check_deck.py — see references/house-style.md:
  * every screen carries the navigation path a user follows to reach it;
  * no catalogue counts are quoted from the prototype.
"""

SAMPLE = ("Screens are live captures of the prototype. The records, codes and amounts "
          "shown are demonstration data.")

# Reusable path prefixes, in the app's own breadcrumb wording.
MODULE = "Core › Settings › Billing"

FIELD_GUIDES = {
    "fg-register": {
        # ---- required -------------------------------------------------------
        "capture": "register",              # capture name from shots/anchors-*.json
        "eyebrow": "The register",          # small caps line above the heading
        "title": "Finding the right record before you touch anything",
        "marks": [                          # (anchor_key, note title, note body)
            ("search", "Search",
             "Matches code, name and description. Search the code when you know it; "
             "search the description when you only know the business rule."),
            ("create", "Create",
             "Opens the three-step form. Covered field by field from here on."),
        ],
        # ---- recommended ----------------------------------------------------
        "sub": "This is where every task starts, whether you are checking an "
               "existing record or about to add one.",
        "path": MODULE + " › Records",
        "note": "Source · the Records tab.",
        # ---- optional -------------------------------------------------------
        # "side": "right",        # badges on the right — use for form fields, whose
        #                         # label sits at the left edge
        # "annotate": False,      # do not draw markers; the screen already numbers
        #                         # its own steps
        # "labels": ["10", "11"], # note labels to use instead of 1, 2, 3 — pair with
        #                         # annotate: False to reuse the app's numbering
    },
}

# Screens shown without markers, keyed the same way. build_deck.py passes each
# to screen(), optionally with a row of short captions.
SCREENS = {
    "overview": {
        "eyebrow": "Where it lives",
        "title": "It is a service, not a separate admin area",
        "sub": "It sits alongside the services whose results depend on it.",
        "path": MODULE,
        "note": SAMPLE,
    },
}

# Captures that go through frame_shot() but are not field guides.
PLAIN = list(SCREENS)
