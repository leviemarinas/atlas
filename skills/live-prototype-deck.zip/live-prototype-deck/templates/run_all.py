# -*- coding: utf-8 -*-
"""Rebuild every asset and the deck, in dependency order.

The first capture step resets the app's stores, so the run always starts from
the same state and counts, screenshots and copy agree.

    python run_all.py
"""
import subprocess
import sys

STEPS = [
    ("Module screens",        "capture_main.py"),
    ("Workflow + GIF frames", "capture_flow.py"),
    ("Walkthrough GIFs",      "make_gifs.py", ["gif-flow:workflow-walkthrough.gif"]),
    ("Deck image assets",     "prepare_images.py"),
    ("Deck",                  "build_deck.py"),
    ("Preview render",        "render_preview.py"),
    ("Contact sheets",        "contact_sheet.py"),
    ("House-rules check",     "check_deck.py"),
]

for step in STEPS:
    label, script = step[0], step[1]
    args = step[2] if len(step) > 2 else []
    print(f"\n=== {label} ({script}) ===", flush=True)
    r = subprocess.run([sys.executable, script] + args, capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    tail = [ln for ln in (r.stdout or "").splitlines() if ln.strip()][-14:]
    print("\n".join(tail))
    if r.returncode != 0:
        print((r.stderr or "")[-2500:])
        sys.exit(f"FAILED: {script}")
print("\nall done — now look at preview/contact-*.png before calling it finished")
