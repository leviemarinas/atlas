# -*- coding: utf-8 -*-
"""Capture the module's main screens.

This is the FIRST capture script, so it resets the app's stores — that is what
makes the whole run repeatable. Later capture scripts must not reset.
"""
from nav import open_module
import shotkit as sk
from shotkit import capture, span, bbox, _rect_of

c = open_module(reset=True)

# ── a full-window establishing shot ────────────────────────────────────────
capture(c, "overview")

# ── a framed region, with an anchor for each note in content.py ────────────
toolbar = _rect_of(c, selector="input[placeholder^='Search']")
last_row = c.js("(()=>{const t=[...document.querySelectorAll('table tbody tr')][9];"
                "if(!t)return null;const r=t.getBoundingClientRect();"
                "return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
capture(c, "register",
        clip_rect=span(toolbar, last_row, pad=22),
        anchors={
            "search": toolbar,
            "create": _rect_of(c, text="Create", tag="button"),
        })

# ── column headers, for a table field guide ────────────────────────────────
def th(i):
    return c.js("(()=>{const h=[...document.querySelectorAll('table thead th')][%d];"
                "if(!h)return null;const r=h.getBoundingClientRect();"
                "return {x:r.x,y:r.y,width:r.width,height:r.height}})()" % i)


table = _rect_of(c, selector="table")
row5 = c.js("(()=>{const t=[...document.querySelectorAll('table tbody tr')][4];"
            "if(!t)return null;const r=t.getBoundingClientRect();"
            "return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
capture(c, "columns", clip_rect=span(table, row5, pad=6),
        anchors={name: th(i) for i, name in enumerate(["code", "name", "status", "action"])})

sk.save("shots/anchors-main.json")
c.close()
print("main captures done")
